import React,{useState,useEffect} from "react";
import Students from "./components/Students";

export default function App() {
  return (
  <>

  <Students/>
  </>
 
    
  );
}


